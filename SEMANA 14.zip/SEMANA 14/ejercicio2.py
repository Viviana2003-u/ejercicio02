# Diccionario principal para almacenar los datos
persona = {
    "habilidades": [],
    "intereses": [],
    "documentos": []
}

# Función para mostrar el menú
def mostrar_menu():
    print("\n--- MENÚ ---")
    print("[1]. INSERTAR")
    print("[2]. MODIFICAR")
    print("[3]. ELIMINAR")
    print("[4]. SALIR")

# Función para insertar datos
def insertar_dato():
    print("\n¿Qué deseas insertar?")
    print("1. Habilidad")
    print("2. Interés")
    print("3. Documento")
    opcion = input("Elige una opción: ")

    if opcion == "1":
        dato = input("Ingresa la nueva habilidad: ")
        persona["habilidades"].append(dato)
    elif opcion == "2":
        dato = input("Ingresa el nuevo interés: ")
        persona["intereses"].append(dato)
    elif opcion == "3":
        dato = input("Ingresa el nuevo documento: ")
        persona["documentos"].append(dato)
    else:
        print("Opción inválida.")

# Función para modificar datos
def modificar_dato():
    print("\n¿Qué deseas modificar?")
    print("1. Habilidad")
    print("2. Interés")
    print("3. Documento")
    opcion = input("Elige una opción: ")

    if opcion in ["1", "2", "3"]:
        clave = "habilidades" if opcion == "1" else "intereses" if opcion == "2" else "documentos"
        print(f"\n{clave.capitalize()} actuales: {persona[clave]}")
        indice = int(input("¿Qué número deseas modificar (0 en adelante)?: "))
        if 0 <= indice < len(persona[clave]):
            nuevo_valor = input("Nuevo valor: ")
            persona[clave][indice] = nuevo_valor
        else:
            print("Índice fuera de rango.")
    else:
        print("Opción inválida.")

# Función para eliminar datos
def eliminar_dato():
    print("\n¿Qué deseas eliminar?")
    print("1. Habilidad")
    print("2. Interés")
    print("3. Documento")
    opcion = input("Elige una opción: ")

    if opcion in ["1", "2", "3"]:
        clave = "habilidades" if opcion == "1" else "intereses" if opcion == "2" else "documentos"
        print(f"\n{clave.capitalize()} actuales: {persona[clave]}")
        indice = int(input("¿Qué número deseas eliminar (0 en adelante)?: "))
        if 0 <= indice < len(persona[clave]):
            eliminado = persona[clave].pop(indice)
            print(f"{clave.capitalize()} '{eliminado}' eliminada.")
        else:
            print("Índice fuera de rango.")
    else:
        print("Opción inválida.")

# Bucle principal
while True:
    mostrar_menu()
    opcion = input("Selecciona una opción: ")

    if opcion == "1":
        insertar_dato()
    elif opcion == "2":
        modificar_dato()
    elif opcion == "3":
        eliminar_dato()
    elif opcion == "4":
        print("Saliendo del programa...")
        break
    else:
        print("Opción no válida. Intenta de nuevo.")

    # Mostrar los datos actuales
    print("\nDatos actuales de la persona:")
    for clave, valores in persona.items():
        print(f"{clave.capitalize()}: {valores}")
